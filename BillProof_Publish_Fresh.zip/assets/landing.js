window.addEventListener('DOMContentLoaded',()=>{
 const url=window.BILLPROOF_CONFIG?.pilotFormUrl;
 if(url && /^https:\/\//i.test(url)) {
  const btn=document.getElementById('pilot-cta');btn.hidden=false;btn.href=url;
  document.getElementById('pilot-status').textContent='Limited pilot places. We will contact applicants with next steps.';
 }
});
