// Deployment settings. Keep empty until accounts/URLs are approved and configured.
window.BILLPROOF_CONFIG = {
  pilotFormUrl: "",
  checkoutUrl: ""
};
